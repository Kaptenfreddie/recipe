KALLA KVARTER — PUBLICERING

Filen index.html är den kompakta Build 3.1-versionen av spelet.

Publicera med GitHub Pages:
1. Skapa/logga in på ett GitHub-konto.
2. Skapa ett nytt repository, t.ex. kalla-kvarter, och välj Public.
3. Ladda upp index.html från den här mappen till repositoryts rot.
4. Öppna Settings > Pages.
5. Under Build and deployment, välj Deploy from a branch.
6. Välj branch main och folder /(root), tryck Save.
7. Vänta tills GitHub Pages visar länken till webbplatsen.

Spelet har redan manuell spara/ladda-funktion via localStorage samt touchknappar för mobil.
Sparningar är lokala för samma webbplats/origin och webbläsare; de synkas inte mellan enheter.
